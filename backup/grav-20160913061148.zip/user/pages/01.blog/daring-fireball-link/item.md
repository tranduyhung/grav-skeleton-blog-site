---
title: Just Some Text Today
date: 13:34 07/10/2014
continue_link: true
link: http://daringfireball.net
taxonomy:
    category: blog
    tag: [journal, link]
---

The blog skeleton also supports **Daring Fireball** style link posts.  Simply add a link setting in your page header:

```
link: http://daringfireball.net
```

And your blog title becomes a link directly to that link you specified. Easy peasy!

